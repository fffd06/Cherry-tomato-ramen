import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { 
  User, 
  Bell, 
  Download, 
  Trash2, 
  Info,
  ChevronRight,
  Save
} from 'lucide-react';

interface SettingsProps {
  userName: string;
  setUserName: (name: string) => void;
  onExportData: () => void;
  onClearData: () => void;
}

export function Settings({ userName, setUserName, onExportData, onClearData }: SettingsProps) {
  const [isEditingName, setIsEditingName] = useState(false);
  const [editedName, setEditedName] = useState(userName);
  const [notifications, setNotifications] = useState({
    budgetAlert: true,
    dailyReminder: false,
    weeklyReport: true,
    challengeReminder: true,
  });

  const handleSaveName = () => {
    setUserName(editedName);
    setIsEditingName(false);
  };

  const handleCancelEdit = () => {
    setEditedName(userName);
    setIsEditingName(false);
  };

  return (
    <div className="space-y-4">
      {/* Profile Section */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-purple-600" />
            <CardTitle className="text-base">프로필</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
              <span className="text-white text-2xl">{userName.charAt(0)}</span>
            </div>
            <div className="flex-1">
              {isEditingName ? (
                <div className="space-y-2">
                  <Input
                    type="text"
                    value={editedName}
                    onChange={(e) => setEditedName(e.target.value)}
                    className="h-10 text-base"
                    placeholder="이름을 입력하세요"
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={handleCancelEdit}
                      variant="outline"
                      size="sm"
                      className="h-8 text-sm"
                    >
                      취소
                    </Button>
                    <Button
                      onClick={handleSaveName}
                      size="sm"
                      className="h-8 text-sm bg-purple-600 hover:bg-purple-700"
                    >
                      <Save className="w-3 h-3 mr-1" />
                      저장
                    </Button>
                  </div>
                </div>
              ) : (
                <div>
                  <p className="text-gray-900">{userName}</p>
                  <button
                    onClick={() => setIsEditingName(true)}
                    className="text-sm text-purple-600 hover:text-purple-700"
                  >
                    이름 수정
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-4">
            <p className="text-sm text-gray-700 mb-1">나의 절약 목표</p>
            <p className="text-lg text-purple-900">이번 달 10만원 절약하기 💰</p>
          </div>
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-purple-600" />
            <CardTitle className="text-base">알림 설정</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-900">예산 초과 알림</p>
              <p className="text-xs text-gray-500">예산을 초과하면 알려드려요</p>
            </div>
            <Switch
              checked={notifications.budgetAlert}
              onCheckedChange={(checked) =>
                setNotifications({ ...notifications, budgetAlert: checked })
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-900">일일 지출 기록 알림</p>
              <p className="text-xs text-gray-500">매일 저녁 9시에 알림</p>
            </div>
            <Switch
              checked={notifications.dailyReminder}
              onCheckedChange={(checked) =>
                setNotifications({ ...notifications, dailyReminder: checked })
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-900">주간 리포트</p>
              <p className="text-xs text-gray-500">매주 월요일 소비 분석</p>
            </div>
            <Switch
              checked={notifications.weeklyReport}
              onCheckedChange={(checked) =>
                setNotifications({ ...notifications, weeklyReport: checked })
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-900">챌린지 알림</p>
              <p className="text-xs text-gray-500">챌린지 달성 시 알림</p>
            </div>
            <Switch
              checked={notifications.challengeReminder}
              onCheckedChange={(checked) =>
                setNotifications({ ...notifications, challengeReminder: checked })
              }
            />
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">데이터 관리</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-3">
          <button
            onClick={onExportData}
            className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors active:scale-98"
          >
            <div className="flex items-center gap-3">
              <Download className="w-5 h-5 text-gray-600" />
              <div className="text-left">
                <p className="text-sm text-gray-900">데이터 내보내기</p>
                <p className="text-xs text-gray-500">CSV 파일로 저장</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          <button
            onClick={() => {
              if (confirm('정말로 모든 데이터를 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.')) {
                onClearData();
              }
            }}
            className="w-full flex items-center justify-between p-3 bg-red-50 hover:bg-red-100 rounded-lg transition-colors active:scale-98"
          >
            <div className="flex items-center gap-3">
              <Trash2 className="w-5 h-5 text-red-600" />
              <div className="text-left">
                <p className="text-sm text-red-900">데이터 초기화</p>
                <p className="text-xs text-red-600">모든 지출 내역 삭제</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-red-400" />
          </button>
        </CardContent>
      </Card>

      {/* App Info */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Info className="w-5 h-5 text-purple-600" />
            <CardTitle className="text-base">앱 정보</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-2">
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-gray-600">버전</span>
            <span className="text-sm text-gray-900">1.0.0</span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-gray-600">개발자</span>
            <span className="text-sm text-gray-900">AI 소비 코치팀</span>
          </div>
          <div className="pt-3 border-t border-gray-100">
            <p className="text-xs text-gray-500 leading-relaxed">
              AI 소비 코치는 대학생의 건강한 소비 습관 형성을 돕는 앱입니다. 
              여러분의 재무 목표 달성을 응원합니다! 🎯
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Support Section */}
      <div className="space-y-2">
        <button className="w-full p-3 text-center text-sm text-purple-600 hover:text-purple-700 bg-white rounded-lg border border-gray-200 active:scale-98 transition-transform">
          이용 약관
        </button>
        <button className="w-full p-3 text-center text-sm text-purple-600 hover:text-purple-700 bg-white rounded-lg border border-gray-200 active:scale-98 transition-transform">
          개인정보 처리방침
        </button>
        <button className="w-full p-3 text-center text-sm text-purple-600 hover:text-purple-700 bg-white rounded-lg border border-gray-200 active:scale-98 transition-transform">
          문의하기
        </button>
      </div>

      {/* Bottom Spacing */}
      <div className="h-4" />
    </div>
  );
}
