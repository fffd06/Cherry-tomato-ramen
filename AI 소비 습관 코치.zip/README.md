
  # AI 소비 습관 코치

  This is a code bundle for AI 소비 습관 코치. The original project is available at https://www.figma.com/design/Il2OipEDUmt1gnrQtzPnoh/AI-%EC%86%8C%EB%B9%84-%EC%8A%B5%EA%B4%80-%EC%BD%94%EC%B9%98.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  