import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { TrendingUp, TrendingDown, AlertCircle, CheckCircle } from 'lucide-react';
import { Expense, Budget } from '../App';
import { SpendingChart } from './SpendingChart';
import { RecentTransactions } from './RecentTransactions';

interface DashboardProps {
  expenses: Expense[];
  budget: Budget;
}

export function Dashboard({ expenses, budget }: DashboardProps) {
  // Calculate total spending this month
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const monthlyExpenses = expenses.filter((expense) => {
    const expenseDate = new Date(expense.date);
    return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear;
  });

  const totalSpent = monthlyExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const budgetUsagePercent = (totalSpent / budget.total) * 100;
  const remaining = budget.total - totalSpent;

  // Calculate category spending
  const categorySpending: { [key: string]: number } = {};
  monthlyExpenses.forEach((expense) => {
    categorySpending[expense.category] = (categorySpending[expense.category] || 0) + expense.amount;
  });

  // Find top 3 categories
  const topCategories = Object.entries(categorySpending)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3);

  // Calculate vs last week
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  
  const thisWeekExpenses = expenses.filter((expense) => {
    const expenseDate = new Date(expense.date);
    return expenseDate >= oneWeekAgo;
  });
  
  const thisWeekTotal = thisWeekExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const avgDailySpending = thisWeekTotal / 7;

  return (
    <div className="space-y-4">
      {/* Overview Cards */}
      <div className="space-y-3">
        <Card className="bg-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-500">이번 달 총 지출</p>
              <span className={`text-xs px-2 py-1 rounded-full ${
                budgetUsagePercent > 100 ? 'bg-red-100 text-red-600' :
                budgetUsagePercent > 80 ? 'bg-orange-100 text-orange-600' :
                'bg-green-100 text-green-600'
              }`}>
                {budgetUsagePercent.toFixed(0)}%
              </span>
            </div>
            <p className="text-2xl text-gray-900 mb-3">{totalSpent.toLocaleString()}원</p>
            <Progress value={budgetUsagePercent} className="h-2" />
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-3">
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
            <CardContent className="p-4">
              <p className="text-xs text-purple-700 mb-1">남은 예산</p>
              <p className={`text-xl ${remaining < 0 ? 'text-red-600' : 'text-purple-900'}`}>
                {remaining.toLocaleString()}원
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
            <CardContent className="p-4">
              <p className="text-xs text-blue-700 mb-1">일평균 (7일)</p>
              <p className="text-xl text-blue-900">
                {avgDailySpending.toLocaleString()}원
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Top 3 Spending Categories */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">TOP 3 지출 항목</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="space-y-3">
            {topCategories.map(([category, amount], index) => {
              const categoryBudget = budget.categories[category] || 0;
              const categoryPercent = categoryBudget > 0 ? (amount / categoryBudget) * 100 : 0;
              const isOverBudget = categoryPercent > 100;

              return (
                <div key={category} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm ${
                        index === 0 ? 'bg-purple-600' :
                        index === 1 ? 'bg-blue-600' :
                        'bg-indigo-600'
                      }`}>
                        {index + 1}
                      </div>
                      <div>
                        <p className="text-sm text-gray-900">{category}</p>
                        <p className="text-xs text-gray-500">
                          {amount.toLocaleString()}원
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {isOverBudget ? (
                        <TrendingUp className="w-4 h-4 text-red-600" />
                      ) : (
                        <TrendingDown className="w-4 h-4 text-green-600" />
                      )}
                      <span className={`text-sm ${isOverBudget ? 'text-red-600' : 'text-green-600'}`}>
                        {categoryPercent.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  <Progress 
                    value={Math.min(categoryPercent, 100)} 
                    className={`h-1.5 ${isOverBudget ? '[&>div]:bg-red-600' : ''}`}
                  />
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Spending Chart */}
      <SpendingChart expenses={monthlyExpenses} />

      {/* Recent Transactions */}
      <RecentTransactions expenses={expenses.slice(0, 10)} />
    </div>
  );
}