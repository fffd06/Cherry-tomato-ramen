import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Expense } from '../App';

interface RecentTransactionsProps {
  expenses: Expense[];
}

export function RecentTransactions({ expenses }: RecentTransactionsProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">최근 거래</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="space-y-2">
          {expenses.map((expense) => {
            const date = new Date(expense.date);
            const formattedDate = `${date.getMonth() + 1}월 ${date.getDate()}일`;

            return (
              <div key={expense.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0 active:bg-gray-50 rounded-lg px-2 -mx-2 transition-colors">
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-900 truncate">{expense.description}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-xs">
                      {expense.category}
                    </Badge>
                    <span className="text-xs text-gray-500">{formattedDate}</span>
                  </div>
                </div>
                <p className="text-sm text-gray-900 ml-3">
                  {expense.amount.toLocaleString()}원
                </p>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}