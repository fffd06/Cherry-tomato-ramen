import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Sparkles, TrendingUp, AlertTriangle, Lightbulb, Target } from 'lucide-react';
import { Expense, Budget } from '../App';

interface AIInsightsProps {
  expenses: Expense[];
  budget: Budget;
}

export function AIInsights({ expenses, budget }: AIInsightsProps) {
  // Calculate insights
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const monthlyExpenses = expenses.filter((expense) => {
    const expenseDate = new Date(expense.date);
    return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear;
  });

  // Category analysis
  const categorySpending: { [key: string]: number } = {};
  monthlyExpenses.forEach((expense) => {
    categorySpending[expense.category] = (categorySpending[expense.category] || 0) + expense.amount;
  });

  // Find problematic categories
  const overBudgetCategories = Object.entries(categorySpending)
    .filter(([category, amount]) => {
      const categoryBudget = budget.categories[category] || 0;
      return amount > categoryBudget;
    })
    .sort(([, a], [, b]) => b - a);

  // Analyze delivery frequency
  const deliveryExpenses = monthlyExpenses.filter((expense) =>
    expense.description.includes('배달') || expense.description.includes('치킨') || 
    expense.description.includes('피자') || expense.description.includes('족발')
  );

  // Analyze cafe frequency
  const cafeExpenses = monthlyExpenses.filter((expense) =>
    expense.category === '카페/간식'
  );

  const totalSpent = monthlyExpenses.reduce((sum, expense) => sum + expense.amount, 0);

  return (
    <div className="space-y-4">
      {/* AI Coach Header */}
      <Card className="bg-gradient-to-br from-purple-600 to-blue-600 text-white">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <p className="text-lg text-white">AI 소비 분석</p>
              <p className="text-sm text-white/80">이번 달 소비 패턴</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Overall Assessment */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-purple-600" />
            <CardTitle className="text-base">종합 분석</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="space-y-3">
            <p className="text-sm text-gray-700 leading-relaxed">
              이번 달 총 <span className="text-purple-600">{totalSpent.toLocaleString()}원</span>을 사용했어요.
              {totalSpent > budget.total ? (
                <span className="text-red-600"> 예산을 {(totalSpent - budget.total).toLocaleString()}원 초과했습니다.</span>
              ) : (
                <span className="text-green-600"> 예산 대비 {((totalSpent / budget.total) * 100).toFixed(1)}% 사용 중이에요.</span>
              )}
            </p>
            
            {deliveryExpenses.length >= 3 && (
              <div className="bg-orange-50 border border-orange-200 rounded-xl p-3">
                <p className="text-sm text-orange-800 leading-relaxed">
                  🍕 이번 달 배달 음식을 <strong>{deliveryExpenses.length}번</strong> 주문했어요. 
                  총 <strong>{deliveryExpenses.reduce((sum, e) => sum + e.amount, 0).toLocaleString()}원</strong>을 사용했습니다.
                </p>
              </div>
            )}

            {cafeExpenses.length >= 5 && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
                <p className="text-sm text-amber-800 leading-relaxed">
                  ☕ 카페를 자주 이용하시네요! <strong>{cafeExpenses.length}번</strong> 방문해서 
                  총 <strong>{cafeExpenses.reduce((sum, e) => sum + e.amount, 0).toLocaleString()}원</strong>을 사용했어요.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Problem Areas */}
      {overBudgetCategories.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <CardTitle className="text-base">주의 항목</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="space-y-3">
              {overBudgetCategories.map(([category, amount]) => {
                const categoryBudget = budget.categories[category] || 0;
                const overAmount = amount - categoryBudget;
                const overPercent = ((amount / categoryBudget) * 100) - 100;

                return (
                  <div key={category} className="bg-red-50 border border-red-200 rounded-xl p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="text-sm text-gray-900">{category}</p>
                        <p className="text-xs text-gray-600">
                          {amount.toLocaleString()}원 / {categoryBudget.toLocaleString()}원
                        </p>
                      </div>
                      <Badge variant="destructive" className="text-xs">
                        +{overPercent.toFixed(0)}%
                      </Badge>
                    </div>
                    <p className="text-xs text-red-700">
                      예산을 {overAmount.toLocaleString()}원 초과
                    </p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Actionable Tips */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-yellow-600" />
            <CardTitle className="text-base">맞춤 절약 팁</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="space-y-3">
            {deliveryExpenses.length >= 3 && (
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
                <p className="text-sm text-blue-900 mb-1">💡 배달 음식 줄이기</p>
                <p className="text-xs text-blue-700 leading-relaxed">
                  배달 주문을 주 1회로 줄이면 월 약 {(deliveryExpenses.reduce((sum, e) => sum + e.amount, 0) * 0.6).toLocaleString()}원을 절약!
                </p>
              </div>
            )}

            {cafeExpenses.length >= 5 && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-3">
                <p className="text-sm text-green-900 mb-1">💡 커피값 절약하기</p>
                <p className="text-xs text-green-700 leading-relaxed">
                  텀블러 할인 활용 시 월 {(cafeExpenses.reduce((sum, e) => sum + e.amount, 0) * 0.4).toLocaleString()}원 절약 가능!
                </p>
              </div>
            )}

            <div className="bg-purple-50 border border-purple-200 rounded-xl p-3">
              <p className="text-sm text-purple-900 mb-1">💡 예산 재조정 제안</p>
              <p className="text-xs text-purple-700 leading-relaxed">
                현재 소비 패턴을 보면, 카페/간식 예산을 늘리고 문화/취미 예산을 줄이는 것이 더 현실적일 수 있어요.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Challenge Suggestion */}
      <Card className="border-2 border-purple-200">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Target className="w-5 h-5 text-purple-600" />
            <CardTitle className="text-base">이번 주 챌린지</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="space-y-3">
            <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-3">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-900">배달음식 1회 이하</p>
                <Badge className="bg-purple-600 text-xs">추천</Badge>
              </div>
              <p className="text-xs text-gray-600 mb-2">
                이번 주 배달 주문을 1회로 제한!
              </p>
              <div className="flex items-center gap-2 text-xs text-purple-700">
                <span>🎯 예상 절약:</span>
                <span>~30,000원</span>
              </div>
            </div>

            <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-3">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-900">카페 방문 주 3회</p>
                <Badge variant="outline" className="text-xs">도전</Badge>
              </div>
              <p className="text-xs text-gray-600 mb-2">
                카페 방문 일주일 3번 제한!
              </p>
              <div className="flex items-center gap-2 text-xs text-green-700">
                <span>🎯 예상 절약:</span>
                <span>~15,000원</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}