import { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { ExpenseInput } from './components/ExpenseInput';
import { AIInsights } from './components/AIInsights';
import { CategoryAnalysis } from './components/CategoryAnalysis';
import { BudgetSetting } from './components/BudgetSetting';
import { Settings } from './components/Settings';
import { LayoutDashboard, TrendingUp, Target, Sparkles, Plus, Settings as SettingsIcon } from 'lucide-react';

// Mock data structure
export interface Expense {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: string;
}

export interface Budget {
  total: number;
  categories: {
    [key: string]: number;
  };
}

const INITIAL_EXPENSES: Expense[] = [
  { id: '1', amount: 5500, category: '카페/간식', description: '스타벅스 아메리카노', date: '2024-11-10' },
  { id: '2', amount: 15000, category: '식비', description: '치킨 배달', date: '2024-11-09' },
  { id: '3', amount: 3200, category: '교통비', description: '지하철', date: '2024-11-08' },
  { id: '4', amount: 12000, category: '문화/취미', description: '영화 관람', date: '2024-11-07' },
  { id: '5', amount: 8900, category: '카페/간식', description: '카페 디저트', date: '2024-11-06' },
  { id: '6', amount: 18000, category: '식비', description: '족발 배달', date: '2024-11-05' },
  { id: '7', amount: 4500, category: '카페/간식', description: '투썸플레이스', date: '2024-11-04' },
  { id: '8', amount: 25000, category: '문화/취미', description: '방탈출 카페', date: '2024-11-03' },
  { id: '9', amount: 6700, category: '교통비', description: '택시', date: '2024-11-02' },
  { id: '10', amount: 13500, category: '식비', description: '피자 배달', date: '2024-11-01' },
];

const INITIAL_BUDGET: Budget = {
  total: 700000,
  categories: {
    '식비': 250000,
    '교통비': 80000,
    '카페/간식': 100000,
    '문화/취미': 150000,
    '기타': 120000,
  },
};

export default function App() {
  const [expenses, setExpenses] = useState<Expense[]>(INITIAL_EXPENSES);
  const [budget, setBudget] = useState<Budget>(INITIAL_BUDGET);
  const [showExpenseInput, setShowExpenseInput] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [userName, setUserName] = useState('지민');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'analysis' | 'insights' | 'budget'>('dashboard');

  const addExpense = (expense: Omit<Expense, 'id'>) => {
    const newExpense = {
      ...expense,
      id: Date.now().toString(),
    };
    setExpenses([newExpense, ...expenses]);
    setShowExpenseInput(false);
  };

  const handleExportData = () => {
    // Create CSV content
    const headers = ['날짜', '카테고리', '설명', '금액'];
    const rows = expenses.map(e => [e.date, e.category, e.description, e.amount]);
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');
    
    // Download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `소비내역_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const handleClearData = () => {
    setExpenses([]);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Mobile Header */}
      <header className="bg-gradient-to-r from-purple-600 to-blue-600 text-white sticky top-0 z-40 shadow-lg">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-white text-lg">AI 소비 코치</h1>
                <p className="text-xs text-white/80">{userName}님, 안녕하세요 👋</p>
              </div>
            </div>
            <button
              onClick={() => setShowSettings(true)}
              className="w-10 h-10 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-xl hover:bg-white/20 active:scale-95 transition-all"
            >
              <SettingsIcon className="w-5 h-5 text-white" />
            </button>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 flex items-center justify-between">
            <div>
              <p className="text-xs text-white/80">이번 달 예산</p>
              <p className="text-white text-lg">{budget.total.toLocaleString()}원</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-white/80">남은 금액</p>
              <p className="text-white text-lg">
                {(budget.total - expenses.filter(e => {
                  const d = new Date(e.date);
                  return d.getMonth() === new Date().getMonth();
                }).reduce((sum, e) => sum + e.amount, 0)).toLocaleString()}원
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-4 py-4">
        {activeTab === 'dashboard' && <Dashboard expenses={expenses} budget={budget} />}
        {activeTab === 'analysis' && <CategoryAnalysis expenses={expenses} budget={budget} />}
        {activeTab === 'insights' && <AIInsights expenses={expenses} budget={budget} />}
        {activeTab === 'budget' && <BudgetSetting budget={budget} setBudget={setBudget} />}
      </main>

      {/* Floating Action Button */}
      <button
        onClick={() => setShowExpenseInput(true)}
        className="fixed bottom-20 right-4 w-14 h-14 bg-gradient-to-br from-purple-600 to-blue-600 text-white rounded-full shadow-lg active:scale-95 transition-transform flex items-center justify-center z-40"
      >
        <Plus className="w-7 h-7" />
      </button>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 safe-area-bottom">
        <div className="grid grid-cols-4 h-16">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'dashboard' ? 'text-purple-600' : 'text-gray-400'
            }`}
          >
            <LayoutDashboard className="w-5 h-5" />
            <span className="text-xs">홈</span>
          </button>
          
          <button
            onClick={() => setActiveTab('analysis')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'analysis' ? 'text-purple-600' : 'text-gray-400'
            }`}
          >
            <TrendingUp className="w-5 h-5" />
            <span className="text-xs">분석</span>
          </button>
          
          <button
            onClick={() => setActiveTab('insights')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'insights' ? 'text-purple-600' : 'text-gray-400'
            }`}
          >
            <Sparkles className="w-5 h-5" />
            <span className="text-xs">AI 코치</span>
          </button>
          
          <button
            onClick={() => setActiveTab('budget')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'budget' ? 'text-purple-600' : 'text-gray-400'
            }`}
          >
            <Target className="w-5 h-5" />
            <span className="text-xs">예산</span>
          </button>
        </div>
      </nav>

      {/* Expense Input Modal */}
      {showExpenseInput && (
        <ExpenseInput
          onClose={() => setShowExpenseInput(false)}
          onAdd={addExpense}
        />
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-white z-50 overflow-y-auto safe-area-bottom">
          <div className="sticky top-0 bg-white border-b border-gray-200 px-4 py-4 z-10">
            <div className="flex items-center justify-between">
              <h2 className="text-lg text-gray-900">설정</h2>
              <button
                onClick={() => setShowSettings(false)}
                className="text-sm text-purple-600 hover:text-purple-700"
              >
                완료
              </button>
            </div>
          </div>
          <div className="px-4 py-4">
            <Settings
              userName={userName}
              setUserName={setUserName}
              onExportData={handleExportData}
              onClearData={handleClearData}
            />
          </div>
        </div>
      )}
    </div>
  );
}