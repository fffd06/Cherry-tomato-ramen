import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Expense, Budget } from '../App';

interface CategoryAnalysisProps {
  expenses: Expense[];
  budget: Budget;
}

const COLORS = [
  '#9333ea', // purple-600
  '#3b82f6', // blue-600
  '#06b6d4', // cyan-600
  '#10b981', // green-600
  '#f59e0b', // amber-600
  '#ef4444', // red-600
  '#8b5cf6', // violet-600
  '#6b7280', // gray-600
];

export function CategoryAnalysis({ expenses, budget }: CategoryAnalysisProps) {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const monthlyExpenses = expenses.filter((expense) => {
    const expenseDate = new Date(expense.date);
    return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear;
  });

  // Calculate spending by category
  const categorySpending: { [key: string]: number } = {};
  monthlyExpenses.forEach((expense) => {
    categorySpending[expense.category] = (categorySpending[expense.category] || 0) + expense.amount;
  });

  // Prepare data for pie chart
  const pieData = Object.entries(categorySpending).map(([name, value]) => ({
    name,
    value,
  }));

  // Get all categories from budget
  const allCategories = Object.keys(budget.categories);

  return (
    <div className="space-y-4">
      {/* Pie Chart */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">카테고리별 지출 비율</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => `${value.toLocaleString()}원`} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Category Details */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">카테고리별 상세</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="space-y-4">
            {allCategories.map((category, index) => {
              const spent = categorySpending[category] || 0;
              const budgetAmount = budget.categories[category];
              const percentage = (spent / budgetAmount) * 100;
              const isOverBudget = percentage > 100;

              // Get expenses for this category
              const categoryExpenses = monthlyExpenses.filter((e) => e.category === category);

              return (
                <div key={category} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full flex-shrink-0"
                        style={{ backgroundColor: COLORS[index % COLORS.length] }}
                      />
                      <div>
                        <p className="text-sm text-gray-900">{category}</p>
                        <p className="text-xs text-gray-500">
                          {categoryExpenses.length}건
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm ${isOverBudget ? 'text-red-600' : 'text-gray-900'}`}>
                        {spent.toLocaleString()}원
                      </p>
                      <p className="text-xs text-gray-500">
                        / {budgetAmount.toLocaleString()}원
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <Progress 
                      value={Math.min(percentage, 100)} 
                      className={`h-1.5 ${isOverBudget ? '[&>div]:bg-red-600' : ''}`}
                    />
                    <div className="flex items-center justify-between text-xs">
                      <span className={isOverBudget ? 'text-red-600' : 'text-gray-600'}>
                        {percentage.toFixed(1)}% 사용
                      </span>
                      {isOverBudget && (
                        <span className="text-red-600">
                          {(spent - budgetAmount).toLocaleString()}원 초과
                        </span>
                      )}
                      {!isOverBudget && budgetAmount > 0 && (
                        <span className="text-green-600">
                          {(budgetAmount - spent).toLocaleString()}원 남음
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Top expenses in category */}
                  {categoryExpenses.length > 0 && (
                    <div className="bg-gray-50 rounded-lg p-3 space-y-2">
                      <p className="text-xs text-gray-600">최근 지출</p>
                      {categoryExpenses.slice(0, 2).map((expense) => (
                        <div key={expense.id} className="flex items-center justify-between text-xs">
                          <span className="text-gray-700 truncate flex-1">{expense.description}</span>
                          <span className="text-gray-900 ml-2">{expense.amount.toLocaleString()}원</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}