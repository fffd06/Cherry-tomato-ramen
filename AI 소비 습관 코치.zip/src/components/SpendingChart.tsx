import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Expense } from '../App';

interface SpendingChartProps {
  expenses: Expense[];
}

export function SpendingChart({ expenses }: SpendingChartProps) {
  // Group expenses by day
  const dailySpending: { [key: string]: number } = {};
  
  expenses.forEach((expense) => {
    const date = new Date(expense.date);
    const dayKey = `${date.getMonth() + 1}/${date.getDate()}`;
    dailySpending[dayKey] = (dailySpending[dayKey] || 0) + expense.amount;
  });

  // Convert to array and sort by date
  const chartData = Object.entries(dailySpending)
    .map(([date, amount]) => ({
      date,
      amount,
    }))
    .sort((a, b) => {
      const [aMonth, aDay] = a.date.split('/').map(Number);
      const [bMonth, bDay] = b.date.split('/').map(Number);
      return aMonth !== bMonth ? aMonth - bMonth : aDay - bDay;
    })
    .slice(-14); // Last 14 days

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">최근 지출 추이</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip 
                formatter={(value: number) => `${value.toLocaleString()}원`}
                contentStyle={{ fontSize: '12px' }}
              />
              <Bar dataKey="amount" fill="#9333ea" name="지출액" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}