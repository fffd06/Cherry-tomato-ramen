import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Budget } from '../App';
import { Save, Edit2 } from 'lucide-react';

interface BudgetSettingProps {
  budget: Budget;
  setBudget: (budget: Budget) => void;
}

export function BudgetSetting({ budget, setBudget }: BudgetSettingProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedBudget, setEditedBudget] = useState(budget);

  const handleSave = () => {
    setBudget(editedBudget);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedBudget(budget);
    setIsEditing(false);
  };

  const updateTotalBudget = (value: string) => {
    const total = parseInt(value) || 0;
    setEditedBudget({ ...editedBudget, total });
  };

  const updateCategoryBudget = (category: string, value: string) => {
    const amount = parseInt(value) || 0;
    setEditedBudget({
      ...editedBudget,
      categories: {
        ...editedBudget.categories,
        [category]: amount,
      },
    });
  };

  const totalCategoryBudget = Object.values(editedBudget.categories).reduce((sum, amount) => sum + amount, 0);
  const budgetDifference = editedBudget.total - totalCategoryBudget;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">예산 설정</CardTitle>
            {!isEditing ? (
              <Button
                onClick={() => setIsEditing(true)}
                variant="outline"
                size="sm"
                className="flex items-center gap-2 h-8 text-sm"
              >
                <Edit2 className="w-3 h-3" />
                수정
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button onClick={handleCancel} variant="outline" size="sm" className="h-8 text-sm">
                  취소
                </Button>
                <Button onClick={handleSave} size="sm" className="bg-purple-600 hover:bg-purple-700 h-8 text-sm">
                  <Save className="w-3 h-3 mr-1" />
                  저장
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-4">
          {/* Total Budget */}
          <div className="space-y-2">
            <Label htmlFor="total-budget" className="text-sm">월 총 예산</Label>
            {isEditing ? (
              <Input
                id="total-budget"
                type="number"
                value={editedBudget.total}
                onChange={(e) => updateTotalBudget(e.target.value)}
                className="h-12 text-base"
              />
            ) : (
              <p className="text-2xl text-gray-900">{budget.total.toLocaleString()}원</p>
            )}
          </div>

          {/* Budget Allocation Warning */}
          {isEditing && budgetDifference !== 0 && (
            <div className={`rounded-xl p-3 ${budgetDifference > 0 ? 'bg-yellow-50 border border-yellow-200' : 'bg-red-50 border border-red-200'}`}>
              <p className={`text-xs ${budgetDifference > 0 ? 'text-yellow-800' : 'text-red-800'}`}>
                {budgetDifference > 0 
                  ? `카테고리 합계가 ${budgetDifference.toLocaleString()}원 적습니다.`
                  : `카테고리 합계가 ${Math.abs(budgetDifference).toLocaleString()}원 초과합니다.`
                }
              </p>
            </div>
          )}

          {/* Category Budgets */}
          <div className="space-y-3">
            <h3 className="text-sm text-gray-900">카테고리별 예산</h3>
            <div className="space-y-3">
              {Object.entries(editedBudget.categories).map(([category, amount]) => (
                <div key={category} className="space-y-2">
                  <Label htmlFor={`budget-${category}`} className="text-sm">{category}</Label>
                  {isEditing ? (
                    <Input
                      id={`budget-${category}`}
                      type="number"
                      value={amount}
                      onChange={(e) => updateCategoryBudget(category, e.target.value)}
                      className="h-10 text-base"
                    />
                  ) : (
                    <div className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-lg">
                      <span className="text-sm text-gray-900">{amount.toLocaleString()}원</span>
                      <span className="text-xs text-gray-500">
                        {((amount / budget.total) * 100).toFixed(1)}%
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Total Category Budget */}
            {isEditing && (
              <div className="pt-3 border-t border-gray-200">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-700">합계</span>
                  <span className="text-gray-900">{totalCategoryBudget.toLocaleString()}원</span>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Budget Tips */}
      <Card className="bg-gradient-to-br from-purple-50 to-blue-50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-purple-900">💡 예산 설정 팁</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-2 text-xs text-purple-800 leading-relaxed">
          <p>• <strong>50/30/20 규칙</strong>: 필수 50%, 선택 30%, 저축 20%</p>
          <p>• <strong>실제 지출 확인</strong>: 최근 3개월 평균 기준</p>
          <p>• <strong>여유 예산</strong>: 예상치 못한 지출 10% 여유</p>
          <p>• <strong>주기적 조정</strong>: 매달 실제 지출 분석 후 조정</p>
        </CardContent>
      </Card>
    </div>
  );
}