import { useState } from 'react';
import { X, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Expense } from '../App';

interface ExpenseInputProps {
  onClose: () => void;
  onAdd: (expense: Omit<Expense, 'id'>) => void;
}

const CATEGORIES = [
  '식비',
  '교통비',
  '카페/간식',
  '문화/취미',
  '쇼핑',
  '생활용품',
  '교육',
  '기타',
];

// AI-based category suggestions based on keywords
const suggestCategory = (description: string): string => {
  const lowerDesc = description.toLowerCase();
  
  if (lowerDesc.includes('카페') || lowerDesc.includes('커피') || lowerDesc.includes('스타벅스') || 
      lowerDesc.includes('디저트') || lowerDesc.includes('베이커리')) {
    return '카페/간식';
  }
  if (lowerDesc.includes('배달') || lowerDesc.includes('치킨') || lowerDesc.includes('피자') || 
      lowerDesc.includes('음식') || lowerDesc.includes('식당') || lowerDesc.includes('밥')) {
    return '식비';
  }
  if (lowerDesc.includes('버스') || lowerDesc.includes('지하철') || lowerDesc.includes('택시') || 
      lowerDesc.includes('교통') || lowerDesc.includes('주유')) {
    return '교통비';
  }
  if (lowerDesc.includes('영화') || lowerDesc.includes('공연') || lowerDesc.includes('게임') || 
      lowerDesc.includes('방탈출') || lowerDesc.includes('노래방')) {
    return '문화/취미';
  }
  if (lowerDesc.includes('옷') || lowerDesc.includes('신발') || lowerDesc.includes('쇼핑') || 
      lowerDesc.includes('화장품')) {
    return '쇼핑';
  }
  if (lowerDesc.includes('책') || lowerDesc.includes('학원') || lowerDesc.includes('강의')) {
    return '교육';
  }
  
  return '기타';
};

export function ExpenseInput({ onClose, onAdd }: ExpenseInputProps) {
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [showAISuggestion, setShowAISuggestion] = useState(false);
  const [suggestedCategory, setSuggestedCategory] = useState('');

  const handleDescriptionChange = (value: string) => {
    setDescription(value);
    
    // Show AI suggestion after user types something
    if (value.length > 2) {
      const suggested = suggestCategory(value);
      setSuggestedCategory(suggested);
      setShowAISuggestion(true);
    } else {
      setShowAISuggestion(false);
    }
  };

  const handleApplySuggestion = () => {
    setCategory(suggestedCategory);
    setShowAISuggestion(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount || !category || !description) {
      return;
    }

    onAdd({
      amount: parseInt(amount),
      category,
      description,
      date,
    });

    // Reset form
    setAmount('');
    setCategory('');
    setDescription('');
    setDate(new Date().toISOString().split('T')[0]);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50">
      <div className="bg-white rounded-t-3xl w-full max-h-[90vh] overflow-y-auto safe-area-bottom animate-slide-up">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-4 py-4 rounded-t-3xl">
          <div className="flex items-center justify-between">
            <h2 className="text-lg text-gray-900">지출 입력</h2>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center text-gray-400 active:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="amount" className="text-sm">금액</Label>
            <Input
              id="amount"
              type="number"
              placeholder="10000"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="h-12 text-base"
              required
              autoFocus
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm">설명</Label>
            <Input
              id="description"
              type="text"
              placeholder="예: 스타벅스 아메리카노"
              value={description}
              onChange={(e) => handleDescriptionChange(e.target.value)}
              className="h-12 text-base"
              required
            />
            {showAISuggestion && (
              <div className="bg-purple-50 border border-purple-200 rounded-xl p-3">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
                    <Sparkles className="w-3 h-3 text-white" />
                  </div>
                  <p className="text-sm text-gray-700">
                    <span className="text-purple-600">{suggestedCategory}</span> 추천
                  </p>
                </div>
                <Button
                  type="button"
                  size="sm"
                  onClick={handleApplySuggestion}
                  className="w-full bg-purple-600 hover:bg-purple-700 h-9"
                >
                  적용하기
                </Button>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="category" className="text-sm">카테고리</Label>
            <Select value={category} onValueChange={setCategory} required>
              <SelectTrigger className="h-12 text-base">
                <SelectValue placeholder="카테고리 선택" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((cat) => (
                  <SelectItem key={cat} value={cat} className="text-base">
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="date" className="text-sm">날짜</Label>
            <Input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="h-12 text-base"
              required
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1 h-12"
            >
              취소
            </Button>
            <Button
              type="submit"
              className="flex-1 h-12 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              추가하기
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}